module.exports=[59402,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_reminders_route_actions_0q8oxuv.js.map