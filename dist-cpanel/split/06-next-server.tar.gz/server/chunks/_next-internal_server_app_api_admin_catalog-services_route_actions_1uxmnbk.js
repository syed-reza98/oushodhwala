module.exports=[45361,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_catalog-services_route_actions_1uxmnbk.js.map