module.exports=[1770,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_campaigns_route_actions_1i4fhho.js.map