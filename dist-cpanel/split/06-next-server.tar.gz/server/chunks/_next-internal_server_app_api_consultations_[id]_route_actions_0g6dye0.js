module.exports=[43066,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_consultations_%5Bid%5D_route_actions_0g6dye0.js.map