module.exports=[20230,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_coa_route_actions_12y7uvp.js.map