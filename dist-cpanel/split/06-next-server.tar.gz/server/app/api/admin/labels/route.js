var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/labels/route.js")
R.c("server/chunks/[root-of-the-server]__0lez06t._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0ck7ku0._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_labels_route_actions_1zr4sxp.js")
R.m(34565)
module.exports=R.m(34565).exports
