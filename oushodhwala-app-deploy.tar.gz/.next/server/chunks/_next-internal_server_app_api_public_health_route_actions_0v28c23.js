module.exports=[27955,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_public_health_route_actions_0v28c23.js.map