module.exports=[15471,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_media_route_actions_0vxfg-a.js.map