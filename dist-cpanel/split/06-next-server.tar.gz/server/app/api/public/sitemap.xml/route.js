var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1a5xdka._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_public_sitemap_xml_route_actions_0k0wv24.js")
R.m(19322)
module.exports=R.m(19322).exports
