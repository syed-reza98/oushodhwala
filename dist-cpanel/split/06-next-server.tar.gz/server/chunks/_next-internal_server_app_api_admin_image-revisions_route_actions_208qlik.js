module.exports=[70100,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_image-revisions_route_actions_208qlik.js.map