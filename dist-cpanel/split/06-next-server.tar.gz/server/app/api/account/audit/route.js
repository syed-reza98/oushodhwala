var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/audit/route.js")
R.c("server/chunks/[root-of-the-server]__0nozhw2._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_account_audit_route_actions_1xatuc9.js")
R.m(12772)
module.exports=R.m(12772).exports
