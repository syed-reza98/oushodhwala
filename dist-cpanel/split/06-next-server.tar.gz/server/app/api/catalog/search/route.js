var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/catalog/search/route.js")
R.c("server/chunks/[root-of-the-server]__03kgugg._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_0ck7ku0._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_catalog_search_route_actions_1haug6a.js")
R.m(98352)
module.exports=R.m(98352).exports
