module.exports=[76581,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_catalog_product_route_actions_084zi8c.js.map