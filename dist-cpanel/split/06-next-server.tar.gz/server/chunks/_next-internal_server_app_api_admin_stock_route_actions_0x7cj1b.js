module.exports=[30576,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_stock_route_actions_0x7cj1b.js.map