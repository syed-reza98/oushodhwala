var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1rbmy1g._.js")
R.c("server/chunks/ssr/node_modules_next_dist_1n3w9lb._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0h7dajk._.js")
R.c("server/chunks/ssr/[root-of-the-server]__17v-f6m._.js")
R.c("server/chunks/ssr/src_app_global-error_tsx_009xrx8._.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0zi5s8-.js")
R.m(40714)
module.exports=R.m(40714).exports
