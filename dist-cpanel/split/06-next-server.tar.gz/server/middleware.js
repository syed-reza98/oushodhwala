var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1w6fxyr._.js")
R.c("server/chunks/[root-of-the-server]__0u3w_r5._.js")
R.m(89997)
module.exports=R.m(89997).exports
