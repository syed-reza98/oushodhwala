module.exports=[66510,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_doctors_%5Bid%5D_availability_route_actions_0i8abbe.js.map