module.exports=[52884,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_account_loyalty_route_actions_1uypm1q.js.map