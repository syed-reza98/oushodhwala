var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/audit/route.js")
R.c("server/chunks/[root-of-the-server]__0y88ym2._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_audit_route_actions_1rkls8g.js")
R.m(34304)
module.exports=R.m(34304).exports
