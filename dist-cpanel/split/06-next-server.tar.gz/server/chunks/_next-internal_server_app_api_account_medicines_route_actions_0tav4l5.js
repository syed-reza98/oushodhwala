module.exports=[25674,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_account_medicines_route_actions_0tav4l5.js.map