var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/route.js")
R.c("server/chunks/[root-of-the-server]__0lqy14c._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1un3wjw._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_orders_route_actions_13s7bso.js")
R.m(99217)
module.exports=R.m(99217).exports
