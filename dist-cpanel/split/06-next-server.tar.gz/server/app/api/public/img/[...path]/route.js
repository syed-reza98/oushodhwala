var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/img/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1csai_3._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_public_img_[___path]_route_actions_0l6e080.js")
R.m(87510)
module.exports=R.m(87510).exports
