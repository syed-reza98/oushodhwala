var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/health/route.js")
R.c("server/chunks/[root-of-the-server]__17tse7b._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_public_health_route_actions_0v28c23.js")
R.m(87783)
module.exports=R.m(87783).exports
