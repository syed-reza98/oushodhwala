module.exports=[2242,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_branches_route_actions_1rwg2-o.js.map