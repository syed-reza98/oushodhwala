module.exports=[68983,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_audit_route_actions_1rkls8g.js.map