module.exports=[50429,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_products_route_actions_1qlniei.js.map