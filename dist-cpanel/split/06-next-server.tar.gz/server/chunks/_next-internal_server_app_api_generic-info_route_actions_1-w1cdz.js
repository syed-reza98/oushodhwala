module.exports=[38346,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_generic-info_route_actions_1-w1cdz.js.map