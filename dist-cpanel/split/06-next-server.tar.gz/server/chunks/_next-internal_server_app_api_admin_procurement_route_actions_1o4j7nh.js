module.exports=[76785,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_procurement_route_actions_1o4j7nh.js.map