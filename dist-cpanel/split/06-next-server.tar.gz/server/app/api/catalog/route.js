var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/catalog/route.js")
R.c("server/chunks/[root-of-the-server]__1rvjdrs._.js")
R.c("server/chunks/_0j7ien5._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0vuhdf7._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_catalog_route_actions_0w1--wy.js")
R.m(91828)
module.exports=R.m(91828).exports
