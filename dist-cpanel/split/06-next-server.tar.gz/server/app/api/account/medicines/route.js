var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/medicines/route.js")
R.c("server/chunks/[root-of-the-server]__05r0xbs._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_account_medicines_route_actions_0tav4l5.js")
R.m(58790)
module.exports=R.m(58790).exports
