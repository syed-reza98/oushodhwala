module.exports=[55305,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_finance-extra_route_actions_06ckg-8.js.map