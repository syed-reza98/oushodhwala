var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/categories/route.js")
R.c("server/chunks/[root-of-the-server]__05y1500._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_categories_route_actions_1lz0ocd.js")
R.m(25106)
module.exports=R.m(25106).exports
