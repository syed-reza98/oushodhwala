module.exports=[68671,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_api-hub_route_actions_0p4bniw.js.map