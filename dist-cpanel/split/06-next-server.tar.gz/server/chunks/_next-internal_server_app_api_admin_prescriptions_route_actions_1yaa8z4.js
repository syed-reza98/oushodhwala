module.exports=[82064,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_prescriptions_route_actions_1yaa8z4.js.map