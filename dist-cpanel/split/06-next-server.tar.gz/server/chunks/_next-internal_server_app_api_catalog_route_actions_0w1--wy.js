module.exports=[5266,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_catalog_route_actions_0w1--wy.js.map