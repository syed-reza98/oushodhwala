module.exports=[30454,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_appointments_route_actions_0xsw_iw.js.map