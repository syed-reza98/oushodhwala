module.exports=[82545,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_catalog_search_route_actions_1haug6a.js.map