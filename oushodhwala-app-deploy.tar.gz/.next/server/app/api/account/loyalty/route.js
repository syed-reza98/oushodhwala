var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/loyalty/route.js")
R.c("server/chunks/[root-of-the-server]__0a0itfk._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_account_loyalty_route_actions_1uypm1q.js")
R.m(70283)
module.exports=R.m(70283).exports
