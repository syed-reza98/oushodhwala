module.exports=[41283,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_offers_route_actions_021t7_q.js.map