var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/doctors/[id]/availability/route.js")
R.c("server/chunks/[root-of-the-server]__15wuksz._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1un3wjw._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_doctors_[id]_availability_route_actions_0i8abbe.js")
R.m(67285)
module.exports=R.m(67285).exports
