globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3gQc8VBVcerL-hhXeC8g1/_buildManifest.js",
    "static/3gQc8VBVcerL-hhXeC8g1/_ssgManifest.js",
    "static/3gQc8VBVcerL-hhXeC8g1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0oeds6xg-zier.js",
    "static/chunks/365_nbyi1e7i8.js",
    "static/chunks/06jxjnw8bfczc.js",
    "static/chunks/0qoeu9b-qoc7g.js",
    "static/chunks/turbopack-10bnvu8x-5nww.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
