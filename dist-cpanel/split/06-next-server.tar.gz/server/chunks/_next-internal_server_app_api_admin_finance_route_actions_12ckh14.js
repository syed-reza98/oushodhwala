module.exports=[37832,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_finance_route_actions_12ckh14.js.map