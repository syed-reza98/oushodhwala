module.exports=[77442,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_categories_route_actions_1lz0ocd.js.map