module.exports=[93373,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_support_route_actions_0u6afou.js.map