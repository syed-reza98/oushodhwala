var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/appointments/route.js")
R.c("server/chunks/[root-of-the-server]__0e6_m1w._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_1fo-or7._.js")
R.c("server/chunks/_0zan2ce._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_appointments_route_actions_0xsw_iw.js")
R.m(44295)
module.exports=R.m(44295).exports
