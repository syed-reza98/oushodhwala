module.exports=[92796,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_labels_route_actions_1zr4sxp.js.map