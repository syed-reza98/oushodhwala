var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/catalog/product/route.js")
R.c("server/chunks/[root-of-the-server]__0md1jjo._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_0ck7ku0._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_catalog_product_route_actions_084zi8c.js")
R.m(24058)
module.exports=R.m(24058).exports
