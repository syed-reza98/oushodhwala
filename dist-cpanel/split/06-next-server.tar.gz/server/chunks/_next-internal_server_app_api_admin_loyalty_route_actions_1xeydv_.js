module.exports=[83807,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_loyalty_route_actions_1xeydv_.js.map