module.exports=[22879,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_delivery_route_actions_1vryxya.js.map