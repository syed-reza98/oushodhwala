module.exports=[78151,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_public_img_%5B___path%5D_route_actions_0l6e080.js.map