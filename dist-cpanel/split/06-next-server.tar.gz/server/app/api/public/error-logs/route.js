var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/error-logs/route.js")
R.c("server/chunks/[root-of-the-server]__19i25bm._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0vuhdf7._.js")
R.c("server/chunks/_next-internal_server_app_api_public_error-logs_route_actions_04j85j4.js")
R.m(69911)
module.exports=R.m(69911).exports
