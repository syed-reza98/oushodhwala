module.exports=[49482,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_returns_route_actions_06dmxr5.js.map